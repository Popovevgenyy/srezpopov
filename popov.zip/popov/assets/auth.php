<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Форма регистрации</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel="stylesheet" href="../boots/bootstrap.css">

    <link rel="stylesheet" href="css/style.css">
</head>
   <body>
    <div class="main"> 
    <?php
if($_COOKIE['user'] == ''):
?> 	
      <input type="checkbox" id="chk" aria-hidden="true">
        <div class="signup">
          <form action="phpform/reg.php" method="post">
            <label for="chk" aria-hidden="true">Регистрация</label>
            <input type="text" name="name" id="name" placeholder="Ваше имя">
            <input type="text" name="surname" id="surname" placeholder="Ваша фамилия" >
            <input type="text" name="login" id="login" placeholder="Ваш логин">
            <input type="text" name="email" id="email" placeholder="Ваше email" >
            <input type="text" name="pass" id="pass" placeholder="Ваш пароль" >
            <button type="submit">Зарегистрироваться</button>
          </form>
        </div>
        <div class="login">
          <form action="phpform/auth.php" method="post">
            <label for="chk" aria-hidden="true">Авторизация</label>
            <input type="text" name="login" id="login" placeholder="Ваш логин" >
            <input type="text" name="pass" id="pass" placeholder="Ваш пароль" >
            <button type="submit">Войти</button>
          </form>
        </div>
    </div>
    <?php else: ?>
        <p>Вы находитесь под пользователем <?=$_COOKIE['user']?>. Что бы выйти нажмите <a href="phpform/exit.php">здесь</a>.</p>
<?php endif;?>
    </body>        
</html>